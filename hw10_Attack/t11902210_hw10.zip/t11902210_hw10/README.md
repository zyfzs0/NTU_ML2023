# 主要程式程式碼參考網站（具體程式碼參考詳解見程式碼中的注釋）
1、I-FGSM （模型理解+程式編寫）
https://zhuanlan.zhihu.com/p/168635420
http://www.pczh.cn/news/15055.html
2、MI-FGSM 
https://blog.csdn.net/iwill323/article/details/128031965
3、model choice （都在要求的model list裡面）
https://github.com/osmr/imgclsmob/blob/master/pytorch/pytorchcv/model_provider.py
(model的選取除了參照這個網站，我還觀摩了很多資料，最後選擇了這些模型，網站太多就不全部列舉出來了)
chatgpt
4、DMI-MI-FGSM （模型理解+程式編寫）
https://blog.csdn.net/weixin_42369818/article/details/125604940?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522168397289016800197070146%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=168397289016800197070146&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-2-125604940-null-null.142^v87^control_2,239^v2^insert_chatgpt&utm_term=%E6%9D%8E%E5%AE%8F%E6%AF%85hw10&spm=1018.2226.3001.4187
5、Ensemble Attack（模型理解+程式編寫）
https://arxiv.org/abs/1611.02770
chatgpt



## 使用model介绍

modify parameters
Ensemble Attack
DIM-MI-FGSM
many right models
MI-FGSM
I-FGSM


### 本次homework的特殊聲明（重要，尤其是第二點）
1、model部分的选择
model的選取除了參照這個網站，我還觀摩了很多資料，最後選擇了這些模型，網站太多就不全部列舉出來了
2、最後生成檔案
ensemble_dmi_mifgsm.tgz

 


