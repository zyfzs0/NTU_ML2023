# 主要程式程式碼參考網站（具體程式碼參考詳解見程式碼中的注釋）
1、殘差神經網路
https://www.cnblogs.com/lccxqk/p/14601537.html
2、殘差神經網路+model
https://blog.csdn.net/iwill323/article/details/127894848
3、Transforms
http://www.360doc.com/content/21/0126/16/73546223_959051784.shtml
4、Transforms
https://blog.csdn.net/Raphael9900/article/details/128207600


## 使用model介绍

Data increase
focus 注意力
cross validation 交叉驗證
setup
test time increase



