# 主要程式程式碼參考網站（具體程式碼參考詳解見程式碼中的注釋）
1、Conformer + SelfAttentionpool +AMsoftmax
https://zhuanlan.zhihu.com/p/483713082
2、TransformerEncoder
https://blog.51cto.com/greyfoss/5707417
3、Conformer
https://github.com/lucidrains/conformer
4、AMsoftmax
https://github.com/wy1iu/sphereface
5、Parameter setting and training epoch writing
https://blog.csdn.net/loco_monkey/article/details/125635953?spm=1001.2101.3001.6650.3&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-3-125635953-blog-121366280.235%5Ev26%5Epc_relevant_recovery_v2&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-3-125635953-blog-121366280.235%5Ev26%5Epc_relevant_recovery_v2&utm_relevant_index=5


## 使用model介绍

Dimension Change
ConformerBlock
Self-attention pooling
Additive margin softmax
Train longer



