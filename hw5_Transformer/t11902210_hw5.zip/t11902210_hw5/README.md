# 主要程式程式碼參考網站（具體程式碼參考詳解見程式碼中的注釋）
1、transformer + lr +parameter
https://zhuanlan.zhihu.com/p/483767828?utm_id=0
2、gradescope problem code
https://blog.csdn.net/weixin_42369818/article/details/124102920


## 使用model介绍

lr
Modify get_ Change the rate function
epoch to 30
transformer architecture


