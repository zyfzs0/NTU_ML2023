# 主要程式程式碼參考網站（具體程式碼參考詳解見程式碼中的注釋）
1、stylegan2
https://github.com/lucidrains/stylegan2-pytorch
2、files renaming
https://blog.csdn.net/weixin_44354586/article/details/103784884
https://blog.csdn.net/weixin_42370340/article/details/102833798
3、gradescope
回答gradescope使用的是diffusion model

## 使用model介绍

stylegan2
秘密武器

