# 主要程式程式碼參考網站（具體程式碼參考詳解見程式碼中的注釋）
1、chinese + QA new model and its use
https://huggingface.co/luhua/chinese_pretrain_mrc_macbert_large
2、unk preprocessing
https://blog.csdn.net/weixin_42369818/article/details/124835855?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522168221931016800226541667%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=168221931016800226541667&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-1-124835855-null-null.142^v86^insert_down1,239^v2^insert_chatgpt&utm_term=%E6%9D%8E%E5%AE%8F%E6%AF%85hw7&spm=1018.2226.3001.4187
3、postprocessing
https://blog.csdn.net/qq_42994201/article/details/121442992
4、learning rate scheduler
https://blog.csdn.net/orangerfun/article/details/120400247
5、no validation
https://gitee.com/yuys0602/NER-BERT-pytorch/


## 使用model介绍

modify parameters
new model 
learning rate scheduler 
preprocessing 
postprocessing 
no validation


